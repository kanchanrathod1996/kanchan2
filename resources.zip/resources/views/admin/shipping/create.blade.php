@extends('admin.layouts.app')

@section('content')

			<!-- Content Header (Page header) -->
            <section class="content-header">					
					<div class="container-fluid my-2">
					
						<div class="row mb-2">
							<div class="col-sm-6">
								<h1>shippin management</h1>
							</div>
							<div class="col-sm-6 text-right">
								<a href="{{route('shipping.index')}}" class="btn btn-primary">Back</a>
							</div>
						</div>
					</div>
					<!-- /.container-fluid -->
				</section>
				<!-- Main content -->
				<section class="content">
					<!-- Default box -->
					<div class="container-fluid">
						@include('front.include.notifications')
						@if(Session::has('message'))
                        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
                        @endif
                    @if(isset($shipping))
                    <form action="{{ route('shipping.update',$shipping->id) }}" method="post" enctype="multipart/form-data">
                        @else
                        
                    {{-- <form action="{{ route('store.new.shipping','id') }}" method="post" enctype="multipart/form-data"> --}}
                      
                        <form action="" method="POST" id="shippingForm" name="shippingForm" enctype="multipart/form-data">
						  @endif
							@csrf
						<div class="card">
							<div class="card-body">								
								<div class="row">
									

									<div class="col-md-6">
										<div class="mb-3">
											{{-- <label for="slug">Amount</label> --}}
											<input type="text" name="amount" id="amount" value="{{ isset($shipping) && $shipping->amount != '' ? $shipping->amount: ''}}" class="form-control" placeholder="amount">
											<p></p>
										</div>
									</div>
                 
	
                                    <div class="col-md-6">
										<div class="mb-3">
											<select name="country" id="country" class="form-control">
												<option value="">Select the country</option>
												<option value="India" {{ isset($shipping) && $shipping->country == 'India' ? 'selected' : '' }}>India</option>
												<option value="Bangladesh" {{ isset($shipping) && $shipping->country == 'Bangladesh' ? 'selected' : '' }}>Bangladesh</option>
												<option value="america" {{ isset($shipping) && $shipping->country == 'america' ? 'selected' : '' }}>America</option>
												<option value="China" {{ isset($shipping) && $shipping->country == 'China' ? 'selected' : '' }}>China</option>
												<option value="France" {{ isset($shipping) && $shipping->country == 'France' ? 'selected' : '' }}>France</option>
												<option value="Thailand" {{ isset($shipping) && $shipping->country == 'Thailand' ? 'selected' : '' }}>Thailand</option>
												<option value="nepal" {{ isset($shipping) && $shipping->country == 'nepal' ? 'selected' : '' }}>Nepal</option>
												<option value="japan" {{ isset($shipping) && $shipping->country == 'japan' ? 'selected' : '' }}>Japan</option>
											</select>
											
											<p></p>
										</div>            
									</div>
	
								</div>
							</div>								
						</div>
                  
						<div class="pb-5 pt-3">
							<button type="submit" class="btn btn-primary">Create</button>
							<a href="{{route('shipping.index')}}" class="btn btn-outline-dark ml-3">Cancel</a>
						</div>
						
                        </form>

						
					</div>
					<!-- /.card -->
				</section>
				
			
			
				
				
				
@endsection

@section('customjs')

<script>
	$(document).ready(function() {
		$('#shippingForm').submit(function(event) {
			event.preventDefault();
			$('button[type="submit"]').prop('disabled', true);
	
			$.ajax({
				method: "post",
				url: '{{ route("shipping.store") }}',
				dataType: 'json',
				data: $(this).serializeArray(),
				success: function(response) {
					
					$('button[type="submit"]').prop('disabled', false);
	
						if (response.status == true) {
							window.location.href = "{{ route('shipping.index') }}";
							
						} else {
							
							var errors = response.errors;
							if (errors.country) {
									$("#country").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.country);
								} else {
									$("#country").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');
								}
			
								if (errors.amount) {
									$("#amount").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.amount);
								} else {
									$("#amount").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');
								}
						}
				}
			});
		});
	});
	</script>
	


@endsection