@extends('admin.layouts.app')

@section('content')

			<!-- Content Header (Page header) -->
            <section class="content-header">					
					<div class="container-fluid my-2">
					<!-- @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif -->
						<div class="row mb-2">
							<div class="col-sm-6">
								<h1>shippin management</h1>
							</div>
							<div class="col-sm-6 text-right">
								<a href="{{route('shipping.create')}}" class="btn btn-primary">Back</a>
							</div>
						</div>
					</div>
					<!-- /.container-fluid -->
				</section>
				<!-- Main content -->
				<section class="content">
					<!-- Default box -->
					<div class="container-fluid">
						@include('front.include.notifications')
						


						{{-- hrere start index page for shipping --}}
						<div class="card">
							<div class="card-body table-responsive p-0">								
								<table class="table table-hover text-nowrap" id="brandList">
									<thead>
										<tr>
											<th>Id</th>
											<th>Amount</th>
											<th>Country</th>
											
											<th>Action</th>
										
										</tr>
									</thead>
									<tbody>
										@if(!empty($shipping))
										@foreach($shipping as $v)
											<tr>    
												<td>{{$v->id}}</td>
												<td>{{ isset($v->amount) && $v->amount != '' ? $v->amount : '' }}</td>
												<td>{{ isset($v->country) && $v->country != '' ? $v->country : '' }}</td>
												<td>
													
														<a class="btn btn-info btn-sm" href="{{ route('shipping.edit', $v->id) }}">Edit</a>
														<a class="btn btn-danger btn-sm" href="{{ route('shipping.delete', $v->id) }}">Delete</a>
													
												</td>
											</tr>
										@endforeach
									@endif

									</tbody>
								</table>										
							</div>
						</div>


					</div>
					<!-- /.card -->
				</section>
				
			@endsection