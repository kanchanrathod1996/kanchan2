@extends('admin.layouts.app')

@section('content')

	<!-- Content Header (Page header) -->
    <section class="content-header">					
        <div class="container-fluid my-2">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Orders</h1>
                </div>
                <div class="col-sm-6 text-right">
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Default box -->
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">                  
                    <form action="{{ route('admin.createOrder') }}" method="GET">
                        <div class="card-header">
                            <div class="card-title">
                                <a href="{{ route('admin.createOrder') }}" class="btn btn-outline-secondary">Reset</a>
                            </div>
                            <div class="card-tools">
                                <div class="input-group input-group" style="width: 250px;">
                                    <input type="text" class="form-control" placeholder="Search by category name" name="keyword" value="{{ request('keyword') }}">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body table-responsive p-0">								
                    <table class="table table-hover text-nowrap">
                        <thead>

                            <tr>
                                <th>Orders #</th>											
                                <th>Customer</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Total</th>
                                <th>Date Purchased</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($shippingaddresses as $customer)
                                <tr>
                                    <td>{{$customer->id}}</td>
                                    <td>{{$customer->first_name}}</td>
                                    <td>{{$customer->email}}</td>
                                    <td>{{$customer->mobile}}</td>
                                    <td>
                                        @foreach($customer->orders as $order)
                                            <span class="badge bg-success">{{$order->status}}</span>
                                        @endforeach
                                    </td>   
                                    <td>
                                        @foreach($customer->orders as $order)
                                            {{$order->total}} 
                                        @endforeach
                                    </td>
                                    <td>{{\Carbon\Carbon::parse($customer->created_at)->format('d M,y')}}</td>
                                    <td><a class="btn btn-info btn-sm" href="{{ route('admin.orderindex', $customer->id)}}">OrderDetails</a></td>
                                    <td><a class="btn btn-danger btn-sm" href="{{ route('admin.createOrder', $customer->id) }}">Delete</a></td>
                                </tr>
                            @endforeach
                        </tbody>
                        
                        
                    </table>										
                </div>
                <div class="card-footer clearfix">
                    {{$shippingaddresses->links('pagination::bootstrap-4')}}
                </div>
            </div>
        </div>
        <!-- /.card -->
    </section>


				
@endsection

@section('customjs')



@endsection