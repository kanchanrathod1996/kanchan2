@extends('front.layouts.app')

@section('content')



<section class="section-5 pt-3 pb-3 mb-3 bg-white">
    <div class="container">

    @if(Session::has('success'))
    <div class="alert alert-success">
        {{Session::get('success')}}
    </div>
    @endif

    @if(Session::has('error'))
    <div class="alert alert-danger">
        {{Session::get('error')}}      
    </div>
    @endif
    
        <div class="light-font">
            <ol class="breadcrumb primary-color mb-0">
                <li class="breadcrumb-item"><a class="white-text" href="{{route('front.home')}}">Home</a></li>
                <li class="breadcrumb-item">Forgot password</li>
            </ol>
        </div>
    </div>
</section>


<section class=" section-10">
    <div class="container">
        <div class="row">
            <div class="col-12">
                {{-- Notifications --}}
                @include('front.include.notifications')
            </div>
        </div>
        <div class="login-form">    
            <form action ="{{route('forget.password.post')}}" method="post">
                @csrf
                <h4 class="modal-title">Forgot Password</h4>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Email" name="email" value="{{old('email')}}">
                @error('email')
                           <p class="invalid-feedback">{{$message}}</p>
                @enderror
                </div>
             
             
                <input type="submit" class="btn btn-dark btn-block btn-lg" value="submit">              
            </form>			
            <div class="text-center small"> <a href="{{route('front.login')}}">Login</a></div>
        </div>
    </div>
</section>
@endsection