
@extends('front.layouts.app')

@section('content')
    <section class="section-5 pt-3 pb-3 mb-3 bg-white">
        <div class="container">
            <div class="light-font">
                <ol class="breadcrumb primary-color mb-0">
                    <li class="breadcrumb-item"><a class="white-text" href="{{route('front.home')}}">Home</a></li>
                    <li class="breadcrumb-item active">Shop</li>
                </ol>
            </div>
        </div>
    </section>

    <section class="section-6 pt-5">
        <div class="container">
            <div class="row">            
                <div class="col-md-3 sidebar">
                    <div class="sub-title">
                        <h2>Categories</h3> 
                    </div>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="accordion accordion-flush" id="accordionExample">
                            @if(!$categories->isEmpty())

                                @foreach ($categories as $key =>$item)
                                <div class="accordion-item">
                                @if(!$item->subcategory->isEmpty())
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne-{{$key}}"
                                         aria-expanded="false" aria-controls="collapseOne">
                                           {{$item->name}}
                                         
                                        </button>
                                    </h2>
                                    @else
                                    <a href= "{{route('front.shop',$item->slug)}}" class="nav-item nav-link  {{($categorySelected == $item->id) ? 'text-primary' : ''}}">{{$item->name}}</a>
                                    @endif
                                    
                                    @if(!$item->subcategory->isEmpty())
                                    <div id="collapseOne-{{$key}}" class="accordion-collapse collapse {{($categorySelected == $item->id) ? 'show' : ''}}" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
                                        <div class="accordion-body">
                                            <div class="navbar-nav">
                                            @foreach($item->subcategory as $value)
                                                <a href="{{route('front.shop',[$item->slug,$value->slug])}}" class="nav-item nav-link  {{($subcategorySelected == $value->id) ? 'text-primary' : ''}}">{{$value->name}}</a>
                                                @endforeach                                  
                                            </div>
                                        </div>
                                    </div>
                                    @endif  
                                </div>  
                                @endforeach
                                @endif
                                    
                            </div>
                        </div>
                    </div>


<!-- end category & subcategory -->
                                                                                

                    <div class="sub-title mt-5">
                        <h2>Brand</h3>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">                                            
                        @if(!$brands->isEmpty())

                           @foreach ($brands as $brand)
                            <div class="form-check mb-2">
                                <input   {{(in_array($brand->id, $brandsArray))? 'checked' : ''}}  class="form-check-input brand-label" type="checkbox" name="brand[]" value="{{$brand->id}}" id="brand-{{$brand->id}}">
                                <label class="form-check-label" for="brand-{{$brand->id}}">
                                   {{$brand->name}}
                                </label>
                            </div>                                              
                            @endforeach                       
                                @endif    
                        </div>                                                                                                  
                    </div>                                                                                                                                                      
   <!-- end brands -->
         </div>                            
                                                                                                                                                                                                                                                                                                                                            

               
                <div class="col-md-9">
                    <div class="row pb-3">
                       

                        @if(!$products->isEmpty())

                          @foreach ($products as $item)
                         
                        <div class="col-md-4">
                            <div class="card product-card">
                                <div class="product-image position-relative">
                                    <a href="#" class="product-img">
                                        @if(!empty($item->image))
                                        <img class="card-img-top" src="/images/{{ $item->image }}"  alt="">
                                        @else  
                                         <img  src="{{asset('admin-assets/img/default-150*150.png')}}"  alt="">
                                        @endif
                                    </a>
                                   
                                    <a onclick ="addToWishList({{$item->id}})"class="whishlist" href="javascript:void(0);"> <i class="far fa-heart"></i>  </a>                          

                                  
                                    <div class="product-action">
                                        <a class="btn btn-dark" href="{{route("front.product",$item->slug)}}">
                                            <i class="fa fa-shopping-cart"></i> Add To Cart
                                        </a>                            
                                    </div>                                                                                                                                                                                                      
                                </div>                        
                                <div class="card-body text-center mt-3">
                                    <a class="h6 link" href="product.php">{{$item->title}}</a>
                                    <div class="price mt-2">
                                        <span class="h5"><strong>${{$item->price}}</strong></span>
                                        <span class="h6 text-underline"><del>$120</del></span>
                                    </div>
                                </div>                        
                            </div> 
                        </div> 
                         @endforeach                       
                     @endif                                                 
                     </div>  
            
 

                        <!-- <div class="col-md-12 pt-5">
                      
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection


@section('customjs')	
<script>
  $(function() {
    $(".brand-label").change(function(){
    apply_filters();

    });
  
});

function apply_filters(){
    var brands = [];
    
    $(".brand-label").each(function(){
        if($(this).is(":checked") == true){
            brands.push($(this).val());
        }

  });
    console.log(brands.toString());
    var url = '{{ url()->current() }}?';
    window.location.href = url+'&brand='+brands.toString();

  }





</script>

@endsection



