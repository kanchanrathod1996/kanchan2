
@extends('front.layouts.app')

@section('content')

<section class="section-5 pt-3 pb-3 mb-3 bg-white">
        <div class="container">
            <div class="container">
                @if(Session::has('success'))
                <div class="alert alert-success">
                    {{Session::get('success')}}
                </div>
                @endif
        
                @if(Session::has('error'))
                <div class="alert alert-danger">
                    {{Session::get('error')}}
                </div>
                @endif
            <div class="light-font">
                <ol class="breadcrumb primary-color mb-0">
                    <li class="breadcrumb-item"><a class="white-text" href="{{route('front.home')}}">Home</a></li>
                    <li class="breadcrumb-item"><a class="white-text" href="{{route('front.shop')}}">Shop</a></li>
                    <li class="breadcrumb-item">{{$product->title}}</li>
                </ol>
            </div>
        </div>
    </section>
  
    <section class="section-7 pt-3 mb-3">
        <div class="container">
           
            <!-- parent classis product_data -->
            <div class="row product_data ">
            <div class="col-md-5">
                    <div id="product-carousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner bg-light">
                            <div class="carousel-item">
                                <img class="w-100 h-100" src="/images/{{ $product->image }}" alt="Image">
                            </div>
                            <div class="carousel-item active">
                                <img class="w-100 h-100" src="/images/{{ $product->image }}" alt="Image">
                            </div>
                            <div class="carousel-item">
                                <img class="w-100 h-100" src="/images/{{ $product->image }}" alt="Image">
                            </div>
                            <div class="carousel-item">
                                <img class="w-100 h-100" src="/images/{{ $product->image }}" alt="Image">
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#product-carousel" data-bs-slide="prev">
                            <i class="fa fa-2x fa-angle-left text-dark"></i>
                        </a>
                        <a class="carousel-control-next" href="#product-carousel" data-bs-slide="next">
                            <i class="fa fa-2x fa-angle-right text-dark"></i>
                        </a>
                    </div>
                </div>
              
                <div class="col-md-7">
                    <div class="bg-light right">
                        <h1>{{$product->title}}</h1>
                        <div class="d-flex mb-3">
                          
                                {{-- <small class="fas fa-star"></small>
                                <small class="fas fa-star"></small>
                                <small class="fas fa-star"></small>
                                <small class="fas fa-star-half-alt"></small>
                                <small class="far fa-star"></small>  --}}
                                <div class="star-rating mt-2" title="{{$avgRatingPer}}%">
                                    <div class="back-stars">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        
                                        <div class="front-stars" style="width: {{$avgRatingPer}}%">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>  
                          
                            <small class="pt-1">   ({{ $product->product_ratings_count }} {{ $product->product_ratings_count > 1 ? 'Reviews' : 'Review'}})</small>
                        </div>
                        <h2 class="price text-secondary"><del>$400</del></h2>
                        <h2 class="price ">${{$product->price}}</h2>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Perferendis officiis dolor aut nihil iste porro ullam repellendus inventore voluptatem nam veritatis exercitationem doloribus voluptates dolorem nobis voluptatum qui, minus facere.</p>
                      
                <hr>
                @if($product->qty > 0)
                <label class="badge bg-success">In Stock</label>
                @else
                <label class="badge bg-danger">Out Of Stock</label>
                 @endif
                <div class="row mt-2">

                            <div class="col-md-3">
                                <input type="hidden" value="{{$product->id}}" class="prod_id">
                                           <label for="Quantity">Quantity</label>
                                           <div class="input-group-text mb-3" style="width:140px;">
                                             <button class="input-group-text decrement-btn ">-</button>
                                             <input type="text" name="quantity " class="form-control  qty-input text-center" value="1">
                                             <button class="input-group-text  increment-btn ">+</button>
                                        
                                            </div>
                             </div>

                                    <div class="col-md-9">
                                        <br/>
                                          <button type="button" class="btn btn-primary me-3  addToCartBtn  float-start" style="margin-left: 20px;">Add to cart<i class="fa fa-shopping-cart"></i></button>

                                            <button type="button" class="btn btn-dark me-3 float-start" >  <a onclick ="addToWishList({{$product->id}})"class="whishlist" href="javascript:void(0);">addToWishList <i class="far fa-heart"></i>  </a>                          
                                               </button>
                                           
                                    </div>
                </div>



             </div>
         </div>

             
                <div class="col-md-12 mt-5">
                    <div class="bg-light">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="description-tab" data-bs-toggle="tab" data-bs-target="#description" type="button" role="tab" aria-controls="description" aria-selected="true">Description</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="shipping-tab" data-bs-toggle="tab" data-bs-target="#shipping" type="button" role="tab" aria-controls="shipping" aria-selected="false">Shipping & Returns</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="reviews-tab" data-bs-toggle="tab" data-bs-target="#reviews" type="button" role="tab" aria-controls="reviews" aria-selected="false">Reviews</button>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                                <p>
                                {{$product->description}}
                                </p>
                            </div>
                            <div class="tab-pane fade" id="shipping" role="tabpanel" aria-labelledby="shipping-tab">
                            <p>
                            {{$product->shipping_returns}}  
                            </p>
                            </div>
                           


                            <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
                                <div class="col-md-8">
                                    <div class="row">
                                  <form action="" name="productRatingForm"id="productRatingForm" method="post">
                                        <h3 class="h4 pb-3">Write a Review</h3>
                                        <div class="form-group col-md-6 mb-3">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" name="username" id="username" placeholder="Name">
                                        <p></p>
                                        </div>
                                        <div class="form-group col-md-6 mb-3">
                                            <label for="email">Email</label>
                                            <input type="text" class="form-control" name="email" id="email" placeholder="Email">
                                            <p></p>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="rating">Rating</label>
                                            <br>
                                            <div class="rating" style="width: 10rem">
                                                <input id="rating-5" type="radio" name="rating" value="5"/><label for="rating-5"><i class="fas fa-3x fa-star"></i></label>
                                                <input id="rating-4" type="radio" name="rating" value="4"  /><label for="rating-4"><i class="fas fa-3x fa-star"></i></label>
                                                <input id="rating-3" type="radio" name="rating" value="3"/><label for="rating-3"><i class="fas fa-3x fa-star"></i></label>
                                                <input id="rating-2" type="radio" name="rating" value="2"/><label for="rating-2"><i class="fas fa-3x fa-star"></i></label>
                                                <input id="rating-1" type="radio" name="rating" value="1"/><label for="rating-1"><i class="fas fa-3x fa-star"></i></label>
                                            </div>
                                            <p class="product-rating-error"></p>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="">How was your overall experience?</label>
                                            <textarea name="comment"  id="comment" class="form-control" cols="30" rows="10" placeholder="How was your overall experience?"></textarea>
                                            <p></p>
                                        </div>
                                        <div>
                                            <button class="btn btn-dark">Submit</button>
                                        </div>
                                   </form>
                                        
                                    </div>
                                </div>
                                <div class="col-md-12 mt-5">
                                    <div class="overall-rating mb-3">
                                        <div class="d-flex">
                                            <h1 class="h3 pe-3">{{$avgRating}}</h1>
                                            <div class="star-rating mt-2" title="{{$avgRatingPer}}%">
                                                <div class="back-stars">
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    
                                                    <div class="front-stars" style="width: {{$avgRatingPer}}%">
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                    </div>
                                                </div>
                                            </div>  
                                            <div class="pt-2 ps-2">
                                                ({{ $product->product_ratings_count }} {{ $product->product_ratings_count > 1 ? 'Reviews' : 'Review'}})
                                            </div>
                                        </div>
                                    </div>
                                
                                    @if($product->product_ratings->isNotEmpty())
                                        @foreach($product->product_ratings as $rating)
                                            @php
                                                $ratingPer = ($rating->rating * 100) / 5;
                                            @endphp
                                
                                            <div class="rating-group mb-4">
                                                <span><strong>{{$rating->username}}</strong></span>
                                                    <div class="star-rating mt-2" title="{{$ratingPer}}%">
                                                        <div class="back-stars">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                            
                                                            <div class="front-stars" style="width: {{$ratingPer}}%">
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                            </div>
                                                        </div>
                                                    </div>   
                                                <div class="my-3">
                                                    <p>{{$rating->comment}}</p>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                                
                            </div>
   

                            
                        </div>
                    </div>
                </div>          
            </div>           
        </div>
    </section>

    <section class="pt-5 section-8">
        <div class="container">
            <div class="section-title">
                <h2>Related Products</h2>
            </div> 
            <div class="col-md-12">
                <div id="related-products" class="carousel">
                @if(!empty($relatedproducts))
                            @foreach($relatedproducts as $relproduct)
                    <div class="card product-card">
                      

                  

                        <div class="product-image position-relative">
                            <a href="" class="product-img"><img class="card-img-top"  src="/images/{{ $relproduct->image }}" alt=""></a>
                            <a onclick ="addToWishList({{$relproduct->id}})"class="whishlist" href="javascript:void(0);"> <i class="far fa-heart"></i>  </a>                          
                           

                            <div class="product-action">
                                <a class="btn btn-dark" href="{{route("front.product",$relproduct->slug)}}">
                                    <i class="fa fa-shopping-cart"></i> Add To Cart
                                </a>                            
                            </div>   
                        </div>                        
                        <div class="card-body text-center mt-3">
                            <a class="h6 link" href="">{{$relproduct->title}}</a>
                            <div class="price mt-2">
                            
                            <span class="h5"><strong>${{$relproduct->price}}</strong></span>
                                
                                   <span class="h5"><strong>$100</strong></span>
                                <span class="h6 text-underline"><del>$120</del></span>
                                
                            </div>
                        </div>                        

                    </div>
                    @endforeach 
                   @endif
                  
                </div>
            </div>
        </div>
    </section>
   
@endsection



@section('customjs')	
<script>
   $(document).ready(function(){
    $('.addToCartBtn').click(function(e){
    e.preventDefault();
    // here .product_data =parent class and .prod_id is child class
    var product_id =$(this).closest('.product_data').find('.prod_id').val();
    var product_qty =$(this).closest('.product_data').find('.qty-input').val();
  
	$.ajax({
            method: "post",
            url: '{{ route("cart.add") }}',
            data: {
                'product_id': product_id,
                'product_qty':product_qty,
			    _token:"{!! csrf_token() !!}"
            },
            success: function(response) {
                alert(response.status);
            }
      });


    });



    //   increament and decrement button  code
    $('.increment-btn ').click(function(e){
    e.preventDefault();
    var inc_value = $('.qty-input').val();
    var value = parseInt(inc_value,10);
    value =isNaN(value) ? 0:value;
         if(value < 10){
            value++
            $('.qty-input').val(value);
         }
  });

  $('.decrement-btn ').click(function(e){
    e.preventDefault();
    var dec_value = $('.qty-input').val();
    var value = parseInt(dec_value,10);
    value =isNaN(value) ? 0:value;
         if(value > 1){
            value--
            $('.qty-input').val(value);
         }
  });
//   end increament and decrement button  code





$('#productRatingForm').submit(function(e) {
    e.preventDefault();
    
    $.ajax({
        url: '{{ route("front.saveRating", $product->id) }}',
        type: 'POST',
        data: $(this).serializeArray(),
        dataType: 'json', 
        success: function(response) {
            var errors = response.errors;
            
            if (response.status == false) {
                if (errors.name) {
                    $("#username").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.name);
                } else {
                    $("#username").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');
                }

                if (errors.email) {
                    $("#email").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.email);
                } else {
                    $("#email").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');
                }

                if (errors.comment) {
                    $("#comment").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.comment);
                } else {
                    $("#comment").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');
                }

                if (errors.rating) {
                    $(".product-rating-error").html(errors.rating);
                } else {
                    $(".product-rating-error").html('');
                }
            } else {
                // Redirect to a specific page or perform other actions upon successful submission
                window.location.href = "{{route('front.product' ,$product->slug)}}"; // Example redirect URL
            }
        }
    });
});

   })

// =====================start rewiew
  

</script>
@endsection




{{--payment::   https://websolutionstuff.com/post/how-to-integrate-cashfree-payment-gateway-in-laravel-10 --}}
{{--    https://meritocracy.is/blog/2021/06/08/laravel-implementing-a-shopping-cart-for-your-website/ --}}