
@extends('front.layouts.app')

@section('content')
<section class="section-5 pt-3 pb-3 mb-3 bg-white">
    <div class="container">
        @if(Session::has('success'))
        <div class="alert alert-success">
            {{Session::get('success')}}
        </div>
        @endif
    
        @if(Session::has('error'))
        <div class="alert alert-danger">
            {{Session::get('error')}}
        </div>
        @endif
    <div class="container">
        <div class="light-font">
            <ol class="breadcrumb primary-color mb-0">
                <li class="breadcrumb-item"><a class="white-text" href="{{route('front.home')}}">Home</a></li>
                <li class="breadcrumb-item"><a class="white-text" href="{{route('front.shop')}}">Shop</a></li>
                <li class="breadcrumb-item">Checkout</li>
            </ol>
        </div>
    </div>
</section>

<section class="section-9 pt-4">
    @include('front.include.notifications')

    <div class="container">
        <form action="javascript:;" id="orderForm" name="orderForm" method="post">

            <div class="row">
                <div class="col-md-8">
                    <div class="sub-title">
                        <h2>Shipping Address</h2>
                    </div>
                    <div class="card shadow-lg border-0">
                        <div class="card-body checkout-form">
                            <div class="row">
                                
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <input type="text" name="first_name" id="first_name" class="form-control" placeholder="First Name" value="{{(!empty($shippingaddress)) ? $shippingaddress->first_name: '' }}" required />
                                    <p></p>
                                    </div>            
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last Name" value="{{(!empty($shippingaddress)) ? $shippingaddress->last_name: '' }}" required />
                                        <p></p>
                                    </div>            
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <input type="text" name="email" id="email" class="form-control" placeholder="Email" value="{{(!empty($shippingaddress)) ? $shippingaddress->email: '' }}" required />
                                        <p></p>
                                    </div>            
                                </div>
    
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <input type="text" name="mobile" id="mobile" class="form-control" placeholder="Mobile No."  value="{{(!empty($shippingaddress)) ? $shippingaddress->mobile: '' }}" required />
                                        <p></p>
                                    </div>            
                                </div>
                                
                                {{-- <div class="col-md-12">
                                    <div class="mb-3">
                                        <select name="country" id="country" class="form-control">
                                            <option value=""> select the country</option>
                                            <option value="India">India</option>
                                            <option value="Bangladesh">	Bangladesh</option>
                                            <option value="america">america</option>
                                            <option value="China">China</option>
                                            <option value="France">France</option>
                                            <option value="Thailand">Thailand</option>
                                            <option value="nepal">nepal</option>
                                            <option value="japan">japan</option>
                                        </select>
                                        <p></p>
                                    </div>            
                                </div>
     --}}
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <textarea name="address" id="address" cols="30" rows="3" placeholder="Address" class="form-control" >{{(!empty($shippingaddress)) ? $shippingaddress->address: '' }}</textarea>
                                        <p></p>
                                    </div>            
                                </div>
    
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <input type="text" name="apartment" id="apartment" class="form-control" placeholder="apartment, suite, unit, etc. (optional)"  value="{{(!empty($shippingaddress)) ? $shippingaddress->apartment: '' }}" required />
                                        <p></p>
                                    </div>            
                                </div>
    
                               
    
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <input type="text" name="city" id="city" class="form-control" placeholder="City"  value="{{(!empty($shippingaddress)) ? $shippingaddress->city: '' }}" required />
                                        <p></p>
                                    </div>            
                                </div>
    
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <input type="text" name="state" id="state" class="form-control" placeholder="State"  value="{{(!empty($shippingaddress)) ? $shippingaddress->state: '' }}"
                                        required />
                                        <p></p>
                                    </div>            
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <input type="text" name="zip" id="zip" class="form-control" placeholder="Zip"  value="{{(!empty($shippingaddress)) ? $shippingaddress->zip: '' }}" required />
                                        <p></p>
                                    </div>            
                                </div>
    
                              
    
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <textarea name="order_notes" id="order_notes" cols="30" rows="2" placeholder="Order Notes (optional)" class="form-control" ></textarea>
                                        <p></p>
                                    </div>            
                                </div>
    
                            </div>
                        </div>
                    </div>    
                </div>

 {{-- Order Summery --}}
                <div class="col-md-4">
                    <div class="sub-title">
                        <h2>Order Summery</h3>
                    </div>                    
                    <div class="card cart-summery">
                        <div class="card-body">
                         
                            <table class="table table-striped  table-bordered ">
                                <thead class="thead-dark">
                                    <tr>
                                        <td>Name</td>
                                        <td>qty</td>
                                        <td>price</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php $total = 0; @endphp
                                    @foreach($cart as $key => $value)
                                    <tr>
                                        <td>{{$value->products->title}}</td>
                                        <td>{{$value->prod_qty}}</td>
                                        <td>{{$value->products->price}}</td> 
                                    </tr>
                                    @php $total += $value->products->price * $value->prod_qty; @endphp
                                    @endforeach   
                                    
                                </tbody>
                            </table>
                           

                            
                          
                         
                            <div class="d-flex justify-content-between mt-2 summery-end">
                              
                                <div class="h6"><strong>SubTotal:</strong></div>
                                <div>{{$total }}</div>
                            
                            
                            </div>    
                            <div class="d-flex justify-content-between mt-2 summery-end">
                                {{-- @php
                                $shipping = App\Models\Shipping::where('id',$value->user_id)->first(); // Replace App\Order with your actual model namespace
                            @endphp --}}
                           
                                <div class="h6"><strong>Shipping:</strong></div>
                            {{-- shipping:{{}} --}}
                                
                            
                            </div>    
                             
                            <div class="d-flex justify-content-between mt-2 summery-end">
                              
                              
                                <div class="h5"><strong>Total:</strong></div>
                               
                                <div>{{$total}}</div>
                            
                            </div>                        
                        </div>
                    </div>   
                    


{{-- Payment Details --}}
                    <div class="card payment-form ">  
                        <h3 class="card-title h5 mb-3">Payment Details</h3>
                        <div>
                            <input checked type="radio" name="payment" value="cod" id="payment_method_one">
                            <label for="payment_method_one" class="form-check-label">COD</label>
                          
                        </div>
                        <div>
                            <input type="radio" name="payment" value="stripe" id="payment_method_two">
                            <label for="payment_method_two" class="form-check-label">stripe</label>
                            
                        </div>
                        
                     
                        <div class="card-body p-0 d-none" id="card-payment-form">
                            <div class="mb-3">
                                <label for="card_number" class="mb-2">Card Number</label>
                                <input type="text" name="card_number" id="card_number" placeholder="Valid Card Number" class="form-control">
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="expiry_date" class="mb-2">Expiry Date</label>
                                    <input type="text" name="expiry_date" id="expiry_date" placeholder="MM/YYYY" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label for="expiry_date" class="mb-2">CVV Code</label>
                                    <input type="text" name="expiry_date" id="expiry_date" placeholder="123" class="form-control">
                                </div>
                            </div>
                           
                        </div>   
                        <div class="pt-4">
                            {{-- <a href="#" >Pay Now</a> --}}
                            <button type="submit"class="btn-dark btn btn-block w-100">place Order</button>
                        </div>                     
                    </div>
    
                          
                    <!-- CREDIT CARD FORM ENDS HERE -->
                    
                </div>
            </div>

        </form>
    </div>
</section>

@endsection












@section('customjs')
<script>
    $(document).ready(function() {
        $("#payment_method_one").click(function() {
            if ($(this).is(":checked")) {
                $("#card-payment-form").addClass('d-none');
            }
        });

        $("#payment_method_two").click(function() {
            if ($(this).is(":checked")) {
                $("#card-payment-form").removeClass('d-none');
            }
        });

        $('#orderForm').submit(function(event) {
            event.preventDefault();
            $('button[type="submit"]').prop('disabled', true);

            $.ajax({
                method: "post",
                url: '{{ route("front.processCheckout") }}',
                dataType: 'json',
                data: $(this).serializeArray(),

                success: function(response) {
                    var errors = response.errors;

                    // Check if there are any errors
                    if (errors) {
                        // Handle errors
                    
                        if(errors.first_name){
                            $("#first_name").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.first_name);
                        }else{
                            $("#first_name").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');

                        }

                        if(errors.last_name){
                            $("#last_name").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.last_name);
                        }else{
                            $("#last_name").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');
                        }

                        if(errors.email){
                            $("#email").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.email);
                        }else{
                            $("#email").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');
                        }

                        if(errors.address){
                            $("#address").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.address);
                        }else{
                            $("#address").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');

                        }

                        if(errors.city){
                            $("#city").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.city);
                        }else{
                            $("#city").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');

                        }


                        if(errors.state){
                            $("#state").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.state);
                        }else{
                            $("#state").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');

                        }

                        if(errors.zip){
                            $("#zip").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.zip);
                        }else{
                            $("#zip").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');

                        }

                        if(errors.mobile){
                            $("#mobile").addClass('is-invalid').siblings("p").addClass('invalid-feedback').html(errors.mobile);
                        }else{
                            $("#mobile").removeClass('is-invalid').siblings("p").removeClass('invalid-feedback').html('');
                        }

                        // Repeat the same for other fields...
                    } else {
                        console.log('success');
                        // If no errors, redirect to thank you page
                        window.location.reload();
                      
                    }
                },
            
                error: function(xhr, status, error) {

                    console.error(xhr.responseText);
                    // Handle error response
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false);
                }
            });
        });
    });
   
</script>
@endsection
