
@extends('front.layouts.app')

@section('content')

 

 <section class="section-5 pt-3 pb-3 mb-3 bg-white">
        <div class="container">
            <div class="light-font">
                <ol class="breadcrumb primary-color mb-0">
                    <li class="breadcrumb-item"><a class="white-text" href="{{route('front.home')}}">Home</a></li>
                    <li class="breadcrumb-item"><a class="white-text" href="{{route('front.shop')}}">Shop</a></li>
                    <li class="breadcrumb-item">Cart</li>
                </ol>
            </div>
        </div>
    </section>



    <section class="section-9 pt-4">
        <div class="container my-5">
            <div class="cart shadow">
                <div class="cart-body">
                    @php $total = 0; @endphp
                    @foreach($cartitems as $item)
                        <div class="row product_data">
                            <div class="col-md-2 pt-4">
                                <img src="/images/{{ $item->products->image }}" width="70px" height="70px">
                            </div>
                            <div class="col-md-3 pt-4">
                                <h6>{{ $item->products->title }}</h6>
                            </div>
                            <div class="col-md-2 pt-4">
                                @if($item->products->qty >= $item->prod_qty)
                                    <h6>{{ $item->products->price }}</h6>
                                @else
                                    <h6>Out Of Stock</h6>
                                    <!-- Or any other message you want to display -->
                                @endif
                            </div>
                            
                            <div class="col-md-3 pt-4">
                                <input type="hidden" value="{{ $item->prod_id }}" class="prod_id">
                                @if($item->products->qty >= $item->prod_qty)
                                    <label for="Quantity">Quantity</label>
                                    <div class="input-group-text mb-3" style="width: 35px;">
                                        <h6>{{ $item->prod_qty }}</h6>
                                    </div>
                                    @php $total += $item->products->price * $item->prod_qty; @endphp
                                @else
                                    <h6>Out Of Stock</h6>
                                @endif
                            </div>
                            <div class="col-md-2 pt-4">
                                @if($item->products->qty >= $item->prod_qty)
                                    <button class="btn btn-sm btn-danger deleteCartItem"><i class="fa fa-trash"></i> remove</button>
                                @else
                                    <button class="btn btn-sm btn-secondary deleteCartItem" disabled>Out Of Stock</button>
                                @endif
                            </div>
                        </div>
                    @endforeach
                    <hr>
                </div>
                <div class="cart-footer p-4">
                    <h3>Total Price: {{ $total }}</h3><br>
                    <a href="{{ route('front.checkout') }}" class="btn btn-dark w-100">Proceed to Checkout</a><br><br>
                    <a href="{{ url('/') }}" class="btn btn-primary btn-block w-100">Continue Shopping</a>
                </div>
            </div>
        </div>
    </section>
    
            
     @endsection



@section('customjs')
<script>
   $(document).ready(function(){
   
   //  End changeQuantity  code



// start Delete code
   $('.deleteCartItem').click(function(e){
    e.preventDefault();

    var prod_id = $(this).closest('.product_data').find('.prod_id').val();


    $.ajax({
            method: "post",
            url: '{{ route("cart.delete") }}',
            data: {
                'prod_id': prod_id,
               
			    _token:"{!! csrf_token() !!}"
            },
            success: function(response) {                                       
                alert(response.status);
                window.location.href = "{{route('cart.viewcart')}}";
            }
      });
     

   });
   // End Delete code



    // ========================

   });



</script>
@endsection