
@extends('front.layouts.app')

@section('content')
<section class="section-5 pt-3 pb-3 mb-3 bg-white">
        <div class="container">
        @if(Session::has('success'))
        <div class="alert alert-success">
            {{Session::get('success')}}
        </div>
        @endif

        @if(Session::has('error'))
        <div class="alert alert-danger">
            {{Session::get('error')}}
        </div>
        @endif
            <div class="light-font">
                <ol class="breadcrumb primary-color mb-0">
                    <li class="breadcrumb-item"><a class="white-text" href="#">My Account</a></li>
                    <li class="breadcrumb-item">Settings</li>
                </ol>
            </div>
        </div>
    </section>

    <section class=" section-11 ">
        <form action =""name="profileForm" id="profileForm">
            @csrf
        <div class="container  mt-5">
            <div class="row">
            <div class="col-12">
                    {{-- Notifications --}}
                    @include('front.include.notifications')
                </div>
                <div class="col-md-3">
                  @include('front.account.common.sidebar')
                </div>
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header">
                            <h2 class="h5 mb-0 pt-2 pb-2">Personal Information</h2>
                        </div>
                        <div class="card-body p-4">
                            <div class="row">
                                <div class="mb-3">               
                                    <label for="name">Name</label>
                                    <input type="text" value="{{$user->name}}" name="name" id="name" placeholder="Enter Your Name" class="form-control">
                                <p></p>
                                </div>
                                <div class="mb-3">            
                                    <label for="email">Email</label>
                                    <input type="text" value="{{$user->email}}"  name="email" id="email" placeholder="Enter Your Email" class="form-control">
                                <p></p>
                                </div>
                                <div class="mb-3">                                    
                                    <label for="phone">Phone</label>
                                    <input type="text" name="phone"  value="{{$user->phone}}" id="phone" placeholder="Enter Your Phone" class="form-control">
                                <p></p>
                                </div>

                                <div class="d-flex">
                                    <button class="btn btn-dark">Update</button>
                                </div>
                            </div>
                        </div>
                      </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection



@section('customjs')
<script>
$("#profileForm").submit(function(event){
    event.preventDefault();


        $.ajax({
                    url:'{{route("front.updateprofile")}}',
                    type:'post',
                    data:$(this).serializeArray(),
                    dataType:'json',
                    _token:"{!! csrf_token() !!}",
                       success:function(response)
                       {

                        var errors = response.errors;

                            if(response.status == false)
                                {

                                   

                                        if(errors.name){
                                            $("#name").siblings("p").addClass('invalid-feedback').html(errors.name);
                                            $("#name").addClass('is-invalid');
                                        }else{
                                            $("#name").siblings("p").removeClass('invalid-feedback').html('');
                                            $("#name").removeClass('is-invalid');
                                        }

                                        if(errors.email){
                                            $("#email").siblings("p").addClass('invalid-feedback').html(errors.email);
                                            $("#email").addClass('is-invalid');
                                        }else{
                                            $("#email").siblings("p").removeClass('invalid-feedback').html('');
                                            $("#email").removeClass('is-invalid');
                                        }


                                        if(errors.phone){
                                            $("#phone").siblings("p").addClass('invalid-feedback').html(errors.phone);
                                            $("#phone").addClass('is-invalid');
                                        }else{
                                            $("#phone").siblings("p").removeClass('invalid-feedback').html('');
                                            $("#phone").removeClass('is-invalid');
                                        }
                        } else{
                            $("#name").siblings("p").removeClass('invalid-feedback').html('');
                            $("#name").removeClass('is-invalid');

                            $("#email").siblings("p").removeClass('invalid-feedback').html('');
                            $("#email").removeClass('is-invalid');

                            $("#phone").siblings("p").removeClass('invalid-feedback').html('');
                            $("#phone").removeClass('is-invalid');

                            window.location.href="{{route('front.profile')}}";
                        }
                    },

                    
                    error:function(jQXHR,execption){
                            console.log("something went wrong");
                    }


       });


})
</script>

@endsection


