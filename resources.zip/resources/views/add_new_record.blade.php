<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Laravel crud never seen before</title>
</head>
<body>
<div class="container">
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="title" style="float:left;">
                        <h1>{!! (isset($record)) ? 'Edit' : 'Add' !!} Add New Record</h1>
                        <h2 class="text-left">Add New Record</h2>
                    </div>
                    <div class="add-button" style="float:right;">
                        <a class="btn btn-dark" href="{{ route('all.records') }}">All Records</a>
                    </div>
                </div>
                <div class="card-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if(Session::has('message'))
                        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
                        @endif
                    @if(isset($record))
                    <form action="{{ route('update.record',$record->id) }}" method="post" enctype="multipart/form-data">
                        @else
                        
                    <form action="{{ route('store.new.record','id') }}" method="post" enctype="multipart/form-data">
                        @endif
                        @csrf
                        <div class="row">
                            <div class="col-md-5">
                                <div class="mb-3">
                                    <label class="mb-1">Name</label>
                                    <input type="text" name="name" class="form-control" value="{{ isset($record) && $record->name != '' ? $record->name: ''}}">
                                </div>
                                <div class="mb-3">
                                    <label class="mb-1">Email</label>
                                    <input type="email" name="email" class="form-control"  value="{{ isset($record) && $record->email != '' ? $record->email: ''}}">
                                </div>
                                {{-- <div class="mb-3">
                                    <label class="mb-1">Age</label>
                                    <input type="number" name="age" class="form-control" value="{{ old('age') }}">
                                </div> --}}
                               
                            </div>
                            <div class="col-md-5 offset-md-1">
                                <div class="form-check-inline mb-3">
                                    <label class="form-check-label mb-1">Gender</label> <br>
                                    <input class="form-check-input" type="radio" name="gender" value="Male" {{ isset($record) && $record->gender == 'Male' ? 'checked': ''}}> Male
                                    <input class="form-check-input" type="radio" name="gender" value="Female" {{ isset($record) && $record->gender == 'Female' ? 'checked': ''}}> Female
                                </div>
                                <div class="mb-3">Occupation</label>
                                    <select name="occupation" class="form-control">
                                        <option value="">Select</option>
                                        <option value="Engineer"  value="Engineer" {{ isset($record) && $record->occupation == 'Engineer' ? 'selected': ''}}>Engineer</option>
                                        <option value="Doctor"  value="Doctor" {{ isset($record) && $record->occupation == 'Doctor' ? 'selected': ''}}>Doctor</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="mb-1">Image</label>
                                    <input type="file" name="image" class="form-control" value="{{ old('image') }}">
                                </div>
                                <div class="mb-3">
                                    <label class="mb-1">Date</label>
                                    <input type="date" name="date" class="form-control" value="{{ isset($record) && $record->date != '' ? $record->date: ''}}">
                                </div>
                                {{-- <div class="mb-3">Occupation</label>
                                    <select name="occupation" class="form-control">
                                        <option value="">Select</option>
                                        <option value="Engineer">Engineer</option>
                                        <option value="Doctor">Doctor</option>
                                    </select>
                                </div>  --}}
                                @php $fruits=$record->fruits;
                                $fruitsArray=explode(',',$fruits);
                                 @endphp
                             {{-- @dd($fruitsArray) --}}
                               <div class="mb-3 form-check">
                                
                                    <label>Which Fruit Do you Like</label><br/>
                                    <input type="checkbox" name="fruits[]" value="Mango" {!! isset($record) && in_array('Mango',$fruitsArray) ? 'checked' : '' !!}> Mango <br/>
                                    <input type="checkbox" name="fruits[]" value="Orange"{!! isset($record) && in_array('Orange',$fruitsArray) ? 'checked' : '' !!}> Orange <br/>
                                    <input type="checkbox" name="fruits[]" value="Apple" {!! isset($record) && in_array('Apple',$fruitsArray) ? 'checked' : '' !!}> Apple <br/>
                                    <input type="checkbox" name="fruits[]" value="Banana" {!! isset($record) && in_array('Banana',$fruitsArray) ? 'checked' : '' !!}> Banana <br/>
                                    <input type="checkbox" name="fruits[]" value="Strawberry" {!! isset($record) && in_array('Strawberry',$fruitsArray) ? 'checked' : '' !!}> Strawberry <br/><br/>
                            
                                </div> 
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>