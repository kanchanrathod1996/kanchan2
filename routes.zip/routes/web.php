<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\CalculatorController;
use App\Http\Controllers\admin\Adminlogincontoller;
use App\Http\Controllers\admin\Dashboardcontoller;
use App\Http\Controllers\admin\Categorycontroller;
use App\Http\Controllers\admin\TempImagecontroller;
use App\Http\Controllers\admin\Subcategorycontroller;
use App\Http\Controllers\admin\Productcontroller;
use App\Http\Controllers\admin\BrandController;
use App\Http\Controllers\admin\Usercontroller;
use App\Http\Controllers\admin\Shippingcontroller;
use App\Http\Controllers\admin\Ordercontroller;
use App\Http\Controllers\Front\Frontcontroller;
use App\Http\Controllers\Front\shopcontroller;
use App\Http\Controllers\Front\Authcontroller;
use App\Http\Controllers\Front\Cartcontroller;
use App\Http\Controllers\Front\Checkoutcontroller;
use App\Http\Controllers\admin\CrudAppController;
use App\Http\Controllers\Auth\ForgotPasswordController;








// $password =  '123456';
// dd(bcrypt($password));
Route::get('/clear-cache', function () {
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('route:clear');
    $exitCode = Artisan::call('view:clear');
    return 'Successfully clear the cache from system!!'; //Return anything
});






  
Route::get('forget-password', [ForgotPasswordController::class, 'showForgetPasswordForm'])->name('forget.password.get');
Route::post('forget-password', [ForgotPasswordController::class, 'submitForgetPasswordForm'])->name('forget.password.post'); 
Route::get('reset-password/{token}', [ForgotPasswordController::class, 'showResetPasswordForm'])->name('reset.password.get');
Route::post('reset-password', [ForgotPasswordController::class, 'submitResetPasswordForm'])->name('reset.password.post');


Route::get('page/{slug}', [Frontcontroller::class, 'page'])->name('front.page');
Route::get('about', [Frontcontroller::class, 'about'])->name('front.about');
Route::get('contact', [Frontcontroller::class, 'contact'])->name('front.contact');
Route::post('sent-Contact-Email', [Frontcontroller::class, 'sentContactEmail'])->name('front.sentContactEmail');

Route::get('/', [Frontcontroller::class, 'index'])->name('front.home');
Route::get('/shop/{categorySlug?}/{subcategorySlug?}', [shopcontroller::class, 'index'])->name('front.shop');
Route::get('/product/{slug}',[shopcontroller::class, 'product'])->name('front.product');
Route::post('/save-rating/{id}', [shopcontroller::class, 'saveRating'])->name('front.saveRating');


// routes/web.php


// Route for adding a product to the cart
Route::post('/cart/add', [CartController::class, 'addProduct'])->name('cart.add');

// Route for viewing the cart
Route::get('/cart', [CartController::class, 'viewcart'])->name('cart.viewcart');

// Route for updating the cart item quantity
Route::post('/cart/update', [CartController::class, 'cartUpdate'])->name('cart.update');

// Route for deleting a cart item
Route::post('/cart/delete', [CartController::class, 'cartDelete'])->name('cart.delete');


// Route::any('cart/add', [Cartcontroller::class, 'addProduct'])->name('cart.add');
// Route::get('cart', [Cartcontroller::class, 'viewcart'])->name('cart.viewcart');
// Route::patch('cart-update', [CartController::class, 'cartUpdate'])->name('cart.update');
// // Route::post('cart-update', [Cartcontroller::class, 'cartUpdate'])->name('cart.update');  
// Route::any('cart-delete', [Cartcontroller::class, 'cartDelete'])->name('cart.delete');
Route::get('checkout', [Checkoutcontroller::class, 'checkout'])->name('front.checkout');
Route::any('process-Checkout', [Checkoutcontroller::class, 'processCheckout'])->name('front.processCheckout');
// Route::get('/thanks', [Checkoutcontroller::class, 'thankyou'])->name('front.thankyou');
Route::get('/thankyou', [CheckoutController::class, 'thankyou'])->name('front.thankyou');
Route::any('add-to-wishlist', [Frontcontroller::class, 'addToWishList'])->name('front.addToWishList');



Route::group(['prefix' => 'front'],function(){
        route::group(['middleware' => 'guest'],function(){  
         

            Route::get('/login',[Authcontroller ::class, 'login'])->name('front.login');
            Route::post('/login',[Authcontroller ::class, 'authenticate'])->name('front.authenticate');
            Route::get('/register',[Authcontroller ::class, 'register'])->name('front.register');
            Route::post('/process-register',[Authcontroller ::class, 'processRegister'])->name('front.processRegister');
          

        });

        route::group(['middleware' => 'auth'],function(){
 
            Route::get('/profile',[Authcontroller ::class, 'profile'])->name('front.profile'); 
            Route::post('/update-profile',[Authcontroller ::class, 'updateProfile'])->name('front.updateprofile'); 
            Route::get('/order',[Authcontroller::class,'order'])->name('front.order');
      
            Route::get('/orderDetail{id}',[Authcontroller::class,'orderDetail'])->name('front.orderDetail');
            Route::get('/my-wishlist',[Authcontroller ::class, 'wishlist'])->name('front.wishlist'); 
            Route::post('/remove-Product-From-Wishlist',[Authcontroller ::class, 'removeProductFromWishlist'])->name('front.removeProductFromWishlist'); 
            
            Route::get('/logout',[Authcontroller ::class, 'logout'])->name('front.logout'); 
            

        });

});


            
Route::group(['prefix' => 'admin'],function(){
    
    route::group(['middleware' => 'admin.guest'],function(){
       
         Route::get('/login', [Adminlogincontoller::class, 'index'])->name('admin.login');
         Route::post('/login', [Adminlogincontoller::class, 'authenticate'])->name('admin.authenticate');
    });

    route::group(['middleware' => 'admin.auth'],function(){

        Route::get('/dashboard', [Dashboardcontoller::class, 'index'])->name('admin.dashboard');
        Route::get('/logout', [Dashboardcontoller::class, 'logout'])->name('admin.logout');

        // category Routes
       
Route::get('categories/index',[Categorycontroller::class,'index'])->name('categories.index');
Route::get('categories/create',[Categorycontroller::class,'create'])->name('categories.create');
Route::any('categories/store',[Categorycontroller::class,'store'])->name('categories.store');

Route::get('categories/edit/{id}',[Categorycontroller::class,'edit'])->name('categories.edit');
Route::any('categories/update/{id}',[Categorycontroller::class,'update'])->name('categories.update');
Route::get('categories/delete/{id}',[Categorycontroller::class,'delete'])->name('categories.delete');
Route::post('categories/changeStatus', [Categorycontroller::class, 'changeStatus'])->name('categories.changeStatus');


Route::post('subcategories/changeStatus', [Subcategorycontroller::class, 'changeStatus'])->name('subcategories.changeStatus');
Route::get('subcategories/index',[Subcategorycontroller::class,'index'])->name('subcategories.index');
Route::get('subcategories/create',[Subcategorycontroller::class,'create'])->name('subcategories.create');
Route::any('subcategories/store',[Subcategorycontroller::class,'store'])->name('subcategories.store');
Route::get('subcategories/show/{id}',[Subcategorycontroller::class,'show'])->name('subcategories.show');
Route::get('subcategories/edit/{id}',[Subcategorycontroller::class,'edit'])->name('subcategories.edit');
Route::any('subcategories/update/{id}',[Subcategorycontroller::class,'update'])->name('subcategories.update');
Route::get('subcategories/delete/{id}',[Subcategorycontroller::class,'delete'])->name('subcategories.delete');


Route::get('product/index',[Productcontroller::class,'index'])->name('product.index');
Route::get('product/create',[Productcontroller::class,'create'])->name('product.create');
Route::any('product/store',[Productcontroller::class,'store'])->name('product.store');
Route::get('product/edit/{id}',[Productcontroller::class,'edit'])->name('product.edit');
Route::any('product/update/{id}',[Productcontroller::class,'update'])->name('product.update');
Route::get('product/delete/{id}',[Productcontroller::class,'delete'])->name('product.delete');
Route::post('product/changeStatus',[Productcontroller::class,'changeStatus'])->name('product.changeStatus');
Route::any('product/getSubCat',[Productcontroller::class,'getSubCat'])->name('product.getSubCat');
Route::any('product/get-products',[Productcontroller::class,'getproducts'])->name('product.getproducts');

Route::get('product/rating',[Productcontroller::class,'Ratingindex'])->name('product.Ratingindex');
Route::post('product/ratingStatus',[Productcontroller::class,'ratingStatus'])->name('product.ratingStatus');

Route::get('brand/index',[BrandController::class,'index'])->name('brand.index');
Route::get('brand/create',[BrandController::class,'create'])->name('brand.create');
Route::any('brand/store',[BrandController::class,'store'])->name('brand.store');
Route::get('brand/show/{id}',[BrandController::class,'show'])->name('brand.show');
Route::get('brand/edit/{id}',[BrandController::class,'edit'])->name('brand.edit');
Route::any('brand/update/{id}',[BrandController::class,'update'])->name('brand.update');
Route::get('brand/delete/{id}',[BrandController::class,'delete'])->name('brand.delete');
Route::post('brand/changeStatus', [BrandController::class, 'changeStatus'])->name('brand.changeStatus');

// order

Route::get('/createOrder',[Ordercontroller::class,'createOrder'])->name('admin.createOrder');
Route::any('/oderdelete/{id}',[Ordercontroller::class,'orderdelete'])->name('admin.orderdelete');
Route::get('/orderindex/{id}',[Ordercontroller::class,'orderindex'])->name('admin.orderindex');

// user 
Route::get('/userindex',[Usercontroller::class,'userindex'])->name('user.userindex');
Route::delete('user/{id}',[Usercontroller::class,'destroy'])->name('delete');
Route::post('user/changeStatus', [Usercontroller::class, 'changeStatus'])->name('user.changeStatus');


// shippin controller
Route::get('shipping/create',[Shippingcontroller::class,'create'])->name('shipping.create');
Route::post('shipping/store',[Shippingcontroller::class,'store'])->name('shipping.store');
Route::get('shipping/edit/{id}',[Shippingcontroller::class,'edit'])->name('shipping.edit');
Route::any('shipping/update/{id}',[Shippingcontroller::class,'update'])->name('shipping.update');
Route::get('shipping/delete/{id}',[Shippingcontroller::class,'delete'])->name('shipping.delete');
Route::get('shipping/index',[Shippingcontroller::class,'index'])->name('shipping.index');

// backend page
Route::get('index',[Dashboardcontoller::class,'indexes'])->name('page.index');
Route::post('store',[Dashboardcontoller::class,'store'])->name('page.store');
Route::get('create',[Dashboardcontoller::class,'create'])->name('page.create');
Route::delete('page/{id}',[Dashboardcontoller::class,'destroy'])->name('delete');
Route::post('/changeStatus', [Dashboardcontoller::class, 'changeStatus'])->name('page.changeStatus');

Route::get('createbrand',[Categorycontroller::class,'createbrand'])->name('createbrand');






    });


});




Route::get('/all_records',[CrudAppController::class,'all_records'])->name('all.records');
Route::get('/add-new-record',[CrudAppController::class,'add_new_record'])->name('add.new.record');
Route::any('/store-new-record',[CrudAppController::class,'store_new_record'])->name('store.new.record');
Route::get('/edit-record/{id}',[CrudAppController::class,'edit_record'])->name('edit.record');
Route::post('/update-record/{id}',[CrudAppController::class,'update_record'])->name('update.record');
Route::get('/delete-record/{id}',[CrudAppController::class,'delete_record'])->name('delete.record');



Route::get('/calculator', function () {
    return view('calculator');
});

Route::post('calculation',[CalculatorController::class,'callcy']);