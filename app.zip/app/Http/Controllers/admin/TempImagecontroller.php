<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TempImage;
use DB;

class TempImagecontroller extends Controller
{
    public function create(Request $request)
    {
        $image = $request->image;

        // $path = storage_path('tmp');

        // if (!file_exists($path)) {
        //     mkdir($path, 0777, true);
        // }
    
        // $image = $request->image;
    
        // $ext = uniqid() . '_' . trim($image ->getClientOriginalName());
    
        // $image->move($path, $ext);
    
        
        if(!empty($image))
        {
            
            $ext = $image->getClientOriginalExtension();
            $newName = time().'-'.rand(0,99).'.'.$ext;

            $tempImage = new TempImage();
            $tempImage->name = $newName;
            $tempImage->save();

            // $image->move(public_path().'/temp',$newName);
            $image->move(public_path('images'),$newName);
            return response()->json([
                 'status'=> true,
                   'image_id'=> $tempImage->id,
                   'message'=>'Image upload successfully'
            ]);

        
    }



}
}
