<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Http\RedirectResponse;
use App\Models\Product;
use App\Models\Subcategory;
use App\Models\Brand;
use App\Models\ProductRating;

use App\Models\Category;
use Illuminate\View\View;

use DB;



class Productcontroller extends Controller
{

  
     public function index(Request $request) {
         // Start with the query builder
         $products = Product::select('products.*')
             ->leftJoin('categories', 'categories.id', '=', 'products.category_id')
             ->leftJoin('subcategories', 'subcategories.id', '=', 'products.subcategory_id')
             ->leftJoin('brands', 'brands.id', '=', 'products.brand_id');
            
     
         // Check if a keyword is provided in the request
         if ($request->has('keyword') && !empty($request->keyword)) {
             $keyword = $request->keyword;
             $products->where(function ($query) use ($keyword) {
                 $query->where('products.title', 'like', '%' . $keyword . '%')
                  
                     ->orWhere('categories.name', 'like', '%' . $keyword . '%')
                     ->orWhere('subcategories.name', 'like', '%' . $keyword . '%')
                     ->orWhere('brands.name', 'like', '%' . $keyword . '%');
                 // Add more fields to search as needed
             });
         }
     
         // Paginate the results
         $products = $products->paginate(10);
     
         // Return the view with the paginated products
         return view('admin.product.index', compact('products'));
     }
     

    public function create()
     {
        
        $category = Category::get();
        $subcategory = Subcategory::get();
        $brand = Brand::get();

        $data['category'] =$category;
        $data['subcategory'] =$subcategory;
        $data['brand'] =$brand;
        return view ('admin.product.create',$data);
    
        
     }
    
    public function  store(Request $request)
    {
      //dd($request);
            $rules = [
            'title' =>'required',
            // 'slug' =>'required',            
            'price' =>'required',
         
             'track_qty'=>'required|in:yes,no',
            // 'image'=> 'mimes:jpeg,jpg,png,gif|max:1000',
            'sku' =>'required',
            'is_featured'=>'required|in:yes,no'
           ]; 
           
           $validator =Validator::make($request->all(),$rules);
           
           if($validator->fails()){
                 return redirect()->back()->withErrors($validator)->withInput();
          }
        
         $product = new Product;
        // dd($product);

         
          $product->title = ($request->title);
          $product->slug = ($request->slug);
          $product->category_id = ($request->category_id);
          $product->subcategory_id = ($request->name);
          $product->brand_id = ($request->brand_id);
          $product->price = ($request->price);
          $product->sku = ($request->sku);
          $product->status = ($request->status);
          $product->is_featured = ($request->is_featured);
          $product->qty = ($request->qty);
          $product->description = ($request->	description);
          $product->shipping_returns = ($request->	shipping_returns);
          $product->related_products = (!empty($request->related_products))? implode(',',$request->related_products) :'';

          // dd($product);

      if(!empty ($request->track_qty) && $request->track_qty =='yes'){
          $rules['qty'] = 'required|numeric';       
         }
        
        //  dd($request->file('image'));
     if ($image = $request->file('image'))
     {
      $destinationPath = 'images/';
      $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
      $image->move($destinationPath, $profileImage);
      $product->image = "$profileImage";
     }
     
     $product->save();

     return redirect('admin/product/index')->with('success','product has been created successfully.');          
    }

   
    public function edit(string $id): View
       {
        $relatedproducts = [];
           $product = Product::find($id);   //SELECT QUERY
           
           $category = Category::get();
           $subcategory = Subcategory::get();
           $brand = Brand::get();

            if($product->related_products!= ''){
                $productArray = explode(',',$product->related_products);
                $relatedproducts = Product::whereIn('id',$productArray)->get();
                
            }
   
           $data['category'] =$category;
           $data['subcategory'] =$subcategory;
           $data['brand'] =$brand;
           $data['product'] =$product; 
           $data['relatedproducts'] =$relatedproducts; 
           return view('admin.product.edit',$data);
       }
       


         
       public function update(Request $request,$id)
       {
        $product =  Product::find($id);
          

        $rules = [
          'title' =>'required',
            'slug' =>'required|unique:products',           
            'price' =>'required|numeric',
         'category' =>'required',
          'track_qty'=>'required|in:yes,no',
            // 'image'=> 'mimes:jpeg,jpg,png,gif|max:1000',
            'sku' =>'required|unique:products,sku,'.$product->id.',id',
            'is_featured'=>'required|in:yes,no'
               
         ]; 

         if(!empty ($request->track_qty) && $request->track_qty =='yes'){
          $rules['qty'] = 'required|numeric';       
         }
         $validator =Validator::make($request->all(),$rules);
         if($validator->passes())
         {
         
          $product =  Product::find($id);
          $product->title = ($request->title);
          $product->slug = ($request->slug);
          $product->category_id = ($request->category);
          $product->subcategory_id = ($request->name);
          $product->brand_id = ($request->brand);
          $product->price = ($request->price);
          $product->sku = ($request->sku);
          $product->status = ($request->status);
          $product->is_featured = ($request->is_featured);
          $product->qty = ($request->qty);
          $product->description = ($request->description);
          $product->shipping_returns = ($request->shipping_returns);
          $product->related_products = (!empty($request->related_products))? implode(',',$request->related_products) :'';

       if ($image = $request->file('image')) {
           $destinationPath = 'images/';
           $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
           $image->move($destinationPath, $profileImage);
           $product['image'] = "$profileImage";
       }else{
           unset($product['image']);
       }
       $product->save();
       return redirect('admin/product/index')->with('success','product has been updated successfully.');

       }


      }
      public function delete($id): RedirectResponse
      {
          $product = Product::find($id);  //SELECT QUERY 
          if ($product)
           {

            $product->delete();
            return redirect('admin/product/index')->with(['success'=> 'Successfully deleted!!']);
        } else {
            return redirect('admin/product/index')->with(['error'=> 'Product not found!!']);
        }
      }

    public function getSubCat(Request $request)
      { 
        $cid = $request->cid;
        $subcategory = Subcategory::with('category')->where('category_id',$cid)->get();
        return response()->json($subcategory);

    }

   public function changeStatus(Request $request) {
  
    $data = $request->all();    

    $product = Product::find($data['id']);

    if ($product->status) {
        $product->status = 0;
    } else {
        $product->status = 1;
    }

    $product->save();

    $array = array();
    $array['status'] = $product->status;
    $array['success'] = true;
    $array['message'] = 'Status changed successfully!';
    echo json_encode($array);
}
    public function getproducts(Request $request)
    {
        $tempProduct = [];
        if($request->term!= ""){
            $products = Product::where('title','like','%'.$request->term.'%')->get();
            if($products!= null){
               foreach($products as $product){
                $tempProduct[] = array('id' => $product->id,
                                         'text'=>$product->title);
                  
               }
            }
        }
      return response()->json([
        'tags'=>$tempProduct,
        'status' =>true
      ]);
    }

// product ratings

    public function Ratingindex(Request $request){
        $productratings =  ProductRating::select('product_ratings.*','products.title as productTitle')
            ->orderBy('product_ratings.created_at', 'DESC')
            ->leftJoin('products', 'products.id','product_ratings.product_id');
        

            

             if ($request->filled('keyword')) {
    $keyword = $request->input('keyword');

    if ($request->filled('keyword')) {
        $keyword = $request->input('keyword');
    
        $productratings->where('products.title', 'like', '%' . $keyword . '%')
            ->orWhere('product_ratings.username', 'like', '%' . $keyword . '%');
    }
}

            $productratings = $productratings->paginate(8);

            return view('admin.product.rating', compact('productratings'));
        }



    
public function ratingStatus(Request $request) {
  
    $data = $request->all();    

    $rating = ProductRating::find($data['id']);

    if ($rating->status) {
        $rating->status = 0;
    } else {
        $rating->status = 1;
    }

    $rating->save();

    $array = array();
    $array['status'] = $rating->status;
    $array['success'] = true;
    $array['message'] = 'Status changed successfully!';
    echo json_encode($array);
}

}
// https://anayadesignerstudio.com/
// Unstitched-Stitched-Half-Saree-for-south-indian-wedding-banner-scaled  