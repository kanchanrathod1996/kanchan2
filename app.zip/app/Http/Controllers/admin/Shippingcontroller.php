<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\TempImage;
use App\Models\Shipping;
 
use DB;

class Shippingcontroller extends Controller
{
public function index(){


  $shipping = Shipping::paginate(7);

  return view('admin.shipping.index',compact('shipping'));


}

    public function create(){


      return view('admin.shipping.create');

    }
    public function store(Request $request){

      $validator = Validator::make($request->all(),[
                   'country' => 'required',
                   'amount' => 'required',
                  ]);
                    
                     if($validator->passes())
                     {
                      $shipping = new Shipping;
                      $shipping->country = $request->country; 
                      $shipping->amount = $request->amount;  
                      $shipping->save();

                      session()->flash('success','shipping added successfully!..');

                      return response()->json([
                         'status' =>true,
                      ]);
                      
                     }else{
                        return response()->json([
                          'status' => false,
                          'errors' => $validator->errors()
                        ]);
                     }
                   

    }

     
    public function edit($id)
    {
        $shipping = Shipping::findOrFail($id);
        return view('admin.shipping.create',compact('shipping'));
        // dd($shipping);
    }
  

      public function update(Request $request,$id)
      {
         
          request() ->validate([
              'amount' =>'required',
              'country' =>'required',
   
             ]); 
      $shipping =  Shipping::find($id);
      $shipping->amount = ($request->amount);
      $shipping->country = ($request->country);
      $shipping->save();
      return redirect()->route('shipping.index')->with('success','country has been updated successfully.');

  


    }
    public function delete($id)
    {
        $shipping = Shipping::find($id);  //SELECT QUERY 
        $shipping->delete();
      
     
        return redirect()->route('shipping.index')->with(['success'=> 'Successfully deleted!!']);
        

    }


}
// https://youtu.be/nRg194eR_ls

// https://youtu.be/qJpnjCtz6tE