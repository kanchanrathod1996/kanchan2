<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\File;
use Illuminate\Http\RedirectResponse;
use App\Models\Category;
use App\Models\Product;
use App\Models\Subcategory ;
use Illuminate\View\View;
use App\Models\TempImage;   
use Image;
use DB;



class Categorycontroller extends Controller
{
        

   
public function index(Request $request)
{
    // Fetch all categories
   
    $categories = Category::query();

    // Check if a keyword is provided in the request
    if ($request->has('keyword') && !empty($request->keyword)) {
        // Filter categories based on the provided keyword
        $categories->where('name', 'like', '%' . $request->keyword . '%');
    }

    // Retrieve the filtered categories
    $categories = $categories->paginate(5);

    // Return the view with the filtered categories
    return view('admin.category.index', compact('categories'));
}

    public function create()
    {
        return view ('admin.category.create');
    }

           public function  store(Request $request){

        
            request() ->validate([
                'name' =>'required|unique:categories',
                // 'slug' =>'required',
              
                'meta_title' =>'required' ,
                'image'=> 'mimes:jpeg,jpg,png,gif|max:1000' 

                
         
               ]); 
          
          $category = new Category;
           $category->name = ($request->name);
           $category->slug = ($request->slug);
         
           $category->meta_title = ($request->meta_title);
           $category->meta_description = ($request->meta_description);
           $category->meta_keywords = ($request->meta_keywords);
           $category->status = ($request->status);
           $category->showhome = ($request->showhome);

           if ($image = $request->file('image'))
           {
           $destinationPath = 'images/';
           $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
           $image->move($destinationPath, $profileImage);
           $category['image'] = "$profileImage";
           }
          
        //    $category->created_by = Auth::user()->id;
          $category->save();
 
        //   dd($category);
           
        return redirect('admin/categories/index')->with('success','Category has been created successfully.');
        }


        public function show(string $id): View
        {
            $category = Category::find($id);    //SELECT QUERY
            return view('admin.category.show',compact('category'));
        }
        
        public function edit(string $id): View
        {
            $category = Category::find($id);   //SELECT QUERY
            return view('admin.category.edit',compact('category'));
        }
        
        
        public function update(Request $request,$id)
        {
           
            request() ->validate([
                'name' =>'required',
                'slug' =>'required|unique:categories',
              
                'meta_title' =>'required'   

                
         
               ]); 
        $category =  Category::find($id);
        $category->name = ($request->name);
        $category->slug = ($request->slug);

        $category->meta_title = ($request->meta_title);
        $category->meta_description = ($request->meta_description);
        $category->meta_keywords = ($request->meta_keywords);
        $category->status = ($request->status);
        $category->showhome = ($request->showhome);

        if ($image = $request->file('image')) {
            $destinationPath = 'images/';
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $category['image'] = "$profileImage";
        }else{
            unset($category['image']);
        }
        $category->save();
        return redirect('admin/categories/index')->with('success','Category has been updated successfully.');

        }


  public function delete($id): RedirectResponse
        {
            // $category = Category::find($id);  //SELECT QUERY 
            // $category->delete();
          
            $category = Category::find($id);
            $category->subcategory()->delete(); // Assuming you have defined the relationship between categories and subcategories in your Category model
            $category->delete();



         
            return redirect('admin/categories/index')->with(['success'=> 'Successfully deleted!!']);
            

        }





   public function changeStatus(Request $request) {

    $data = $request->all();    

    $Cat = Category::find($data['id']);

    if ($Cat->status) {
        $Cat->status = 0;
    } else {
        $Cat->status = 1;
    }

    $Cat->save();

    $array = array();
    $array['status'] = $Cat->status;
    $array['success'] = true;
    $array['message'] = 'Status changed successfully!';
    echo json_encode($array);
}



}




