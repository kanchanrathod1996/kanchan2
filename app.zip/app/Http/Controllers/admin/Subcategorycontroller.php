<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Http\RedirectResponse;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\View\View;

use DB;



class Subcategorycontroller extends Controller
{
 
    public function index(Request $request) {
        // Start with the query builder
        $subcategories = Subcategory::select('subcategories.*', 'categories.name as categoryName')
            ->latest('subcategories.id')
            ->leftJoin('categories', 'categories.id', 'subcategories.category_id');
    
        // Check if a keyword is provided in the request
        if ($request->has('keyword') && !empty($request->keyword)) {
            // Filter subcategories based on the provided keyword
            $keyword = $request->keyword;
            $subcategories->where(function ($query) use ($keyword) {
                $query->where('subcategories.name', 'like', '%' . $keyword . '%')
                    ->orWhere('categories.name', 'like', '%' . $keyword . '%');
            });
        }
    
        // Paginate the results
        $subcategories = $subcategories->paginate(5);
    
        // Return the view with the paginated subcategories
        return view('admin.subcategory.index', compact('subcategories'));
    }
    

    public function create()
    {

        $category = Category::get();
    //    dd('$category');
        return view ('admin.subcategory.create',compact('category'));
    }

    public function  store(Request $request){
        
        request() ->validate([
          
            'name' =>'required|unique:subcategories',
            // 'slug' =>'required',    
           
            'meta_title' =>'required'
   
           ]); 
          
      $subcategory = new Subcategory;
      
      $subcategory->category_id = ($request->category_id);
      $subcategory->name = ($request->name);
      $subcategory->slug = ($request->slug);
      $subcategory->status = ($request->status);
      $subcategory->showhome = ($request->showhome);
      $subcategory->meta_title = ($request->meta_title);
      $subcategory->meta_description = ($request->meta_description);
      $subcategory->meta_keywords = ($request->meta_keywords);
   //    $subcategory->created_by = Auth::user()->id;
     $subcategory->save();

    //  dd('$subcategory');
      
   return redirect('admin/subcategories/index')->with('success','SubCategory has been created successfully.');
   }

   public function edit(string $id): View
   {
        $category = Category::get();
       $subcategory = Subcategory::find($id);   //SELECT QUERY
       return view('admin.subcategory.edit',compact('subcategory','category'));
   }
   
   
   public function update(Request $request,$id)
   {
      
       request() ->validate([
           'name' =>'required|unique:subcategories',
           'slug' =>'required',
         
           'meta_title' =>'required'   

           
    
          ]); 
      $subcategory =  Subcategory::find($id);
      $subcategory->category_id = ($request->category_id);
      $subcategory->name = ($request->name);
      $subcategory->slug = ($request->slug);
      $subcategory->status = ($request->status);
      $subcategory->showhome = ($request->showhome);
      $subcategory->meta_title = ($request->meta_title);
      $subcategory->meta_description = ($request->meta_description);
      $subcategory->meta_keywords = ($request->meta_keywords);
      $subcategory->save();
        
   return redirect('admin/subcategories/index')->with('success','subcategory has been updated successfully.');
   }


public function delete($id): RedirectResponse
   {
       $subcategory = Subcategory::find($id);  //SELECT QUERY 
       $subcategory->delete();
     
    
       return back()->with(['success'=> 'Successfully deleted!!']);
       

   }

   public function changeStatus(Request $request) {

        $data = $request->all();

        $subCat = Subcategory::find($data['id']);

        if ($subCat->status) {
            $subCat->status = 0;
        } else {
            $subCat->status = 1;
        }

        $subCat->save();

        $array = array();
        $array['status'] = $subCat->status;
        $array['success'] = true;
        $array['message'] = 'Status changed successfully!';
        echo json_encode($array);
    }
   


    
}
