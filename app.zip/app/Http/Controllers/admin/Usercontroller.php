<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;


use DB;

class Usercontroller extends Controller
{

     public function userindex(Request $request)
     {
        
         
          $query = User::query();

          if ($request->has('keyword') && !empty($request->keyword)) {
              $query->where('name', 'like', '%' . $request->keyword. '%');
          }

          $user = $query->paginate(6);

          return view ('admin.user.userindex',compact('user'));
     }


   public function changeStatus(Request $request) {

     $data = $request->all();    
 
     $user = User::find($data['id']);
 
     if ($user->status) {
         $user->status = 0;
     } else {
         $user->status = 1;
     }
 
     $user->save();
 
     $array = array();
     $array['status'] = $user->status;
     $array['success'] = true;
     $array['message'] = 'Status changed successfully!';
     echo json_encode($array);
 }



 public function destroy($id) {
    $user = User::findOrFail($id);


    $user->destroy($id);
    $array = array();
    $array['success'] = true;
    $array['message'] = 'Userdata deleted successfully!';
    echo json_encode($array);

}
}