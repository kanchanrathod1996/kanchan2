<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Http\RedirectResponse;
use App\Models\Order;
use App\Models\OrderItem;

use App\Models\ShippingAddress;
use App\Models\User;
use Illuminate\View\View;
use DB;



class Ordercontroller extends Controller
{
    public function createOrder(Request $request)   
    {
        // Start with the query builder
        
        // Retrieve customer addresses paginated
        $shippingaddresses = ShippingAddress::paginate(7);
        
        // Retrieve all orders
        $orders = Order::all();
    
        // Pass the retrieved data to the view
        return view('admin.order.create', compact('shippingaddresses', 'orders'));
    }
    

    public function orderindex($id){
        $shippingaddresses = ShippingAddress::get();
        $order = Order::where('id',$id)->get();
        $orderitem = OrderItem::where('orderId',$id)->get();//get orderId from orderitem table
      

        return view ('admin.order.orderindex',compact('order','orderitem','shippingaddresses'));
    }
    public function orderdelete($id){

      
        $orders = Order::find($id);  //SELECT QUERY 
        $orders->delete();
      
     
        return redirect('admin/order/createOrder')->with(['success'=> 'Successfully deleted!!']);

    }
}