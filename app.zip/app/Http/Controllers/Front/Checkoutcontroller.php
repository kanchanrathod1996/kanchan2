<?php
  
namespace App\Http\Controllers\Front;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Validator;
use App\Models\ShippingAddress;
use Session;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\OrderMaster;

use App\Models\OrderItem;
use App\Models\Order;
use App\Models\Cart;


use App\Models\Subcategory;
use DataTables;
use File;

use Hash; 
use DB;
class Checkoutcontroller extends Controller
   {


    public function checkout(Request $request){

// remove outofStock
        $old_cartitems =Cart::where('user_id',Auth::id())->get();//remove frome out of stock
        foreach($old_cartitems as $item)
        {
          if(!product::where('id',$item->prod_id)->where('qty','>=',$item->prod_qty)->exists()){

               $removeItem = Cart::where('user_id', Auth::id())->where('prod_id',$item->prod_id)->first();
               $removeItem->delete();
              }
            //  $cartitems = Cart::where('user_id', Auth::id())->get();
        }

        $cart = $request->session()->get('cart', []);
        $cart = Cart::where('user_id',Auth::id())->get();
        $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
     
    
     
        
        // if user is not login than redirect to loginpage cheking url 
        if(Auth::check()==false)
        {
            if(!session()->has('url.intended'))
            {
                session(['url.intended' => url()->current()]);  
            }
           

            
            return redirect()->route('front.login');

        }
            // if cart is empty redirect to cartpage

        if ($cart->isEmpty()) {
            return redirect()->route('cart.viewcart');
        }
       
        // atometic fill the customerAddress table
        $shippingaddress = ShippingAddress::where('user_id',Auth::user()->id)->first();

      

        session()->forget('url.intended');



// Pass the variables to the view
return view('front.checkout', compact('categories', 'cart','shippingaddress'));
}

public function processCheckout(Request $request)
{

    $user = Auth::user();

// Validate the request data
$validator = Validator::make($request->all(), [
    'first_name' => 'required|min:5', 
    'last_name' => 'required',
    'email' => 'required|email',
    'mobile' => 'required',   
    'address' => 'required',
    'city' => 'required',
    'state' => 'required',
    'zip' => 'required',  
]);

// Check for validation failure
if ($validator->fails()) {
    return response()->json([
        'message' => 'Please fix the errors',
        'status' => false,
        'errors' => $validator->errors()
    ]);
}

// Get the authenticated user
$user = Auth::user();

// Determine the orderId
$orderId = $request->orderId ?? null; // Use null if orderId is not provided in the request


ShippingAddress::updateOrCreate(
    ['user_id' =>$user->id],
                               
    [ 
   'user_id' => $user->id, 
   'first_name' => $request->first_name, 
    'last_name' => $request->last_name,
    'email' => $request->email,
    'mobile' => $request->mobile,
  
    'address' => $request->address,
    'apartment' => $request->apartment,
    'city' => $request->city,
    'state' => $request->state,
    'zip' => $request->zip,
    
    ], $request->all());
 
 

// $shipping = new ShippingAddress();
// $shipping ->user_id = $user->id;
// $shipping->orderId= $orderId;
// $shipping->first_name =$request->first_name ;
// $shipping->last_name = $request->last_name;
// $shipping->email = $request->email;
// $shipping->mobile = $request->mobile;
// $shipping ->address = $request->address;
// $shipping->apartment = $request->apartment;
// $shipping->city = $request->city;
// $shipping->state = $request->state;
// $shipping->zip=$request->zip;
// $shipping->save();

  
           // Check if the cart has items
           $cart = Cart::where('user_id', Auth::id())->get();
           if ($cart->isEmpty()) {
               return redirect()->back()->with('error_message', 'Cart is empty.');
           }
   
           $order = new Order();
           $order->status = "pending";
           $order->user_id = $user->id;
   
           $total = 0;
   
           foreach ($cart as $item) {
               $product = Product::find($item->prod_id);
   
               $orderItem = new OrderItem();
               $orderItem->prod_id = $item->prod_id;
               $orderItem->prod_qty = $item->prod_qty;
               $orderItem->price = $product->price;
               $orderItem->orderId = $item->id;
               $orderItem->save();
   
               $total += $item->prod_qty * $product->price;
           }
   

           $order->total = $total;
           $order->save();
           session()->flash('success','Order has been sent successfully.');
           // Destroy cart
           Cart::where('user_id', $user->id)->delete();

           $payment = $request->payment;
           
         if ($request->payment == 'cod') {
           // Set success message and redirect to thank you page
           
           return redirect()->route('front.thankyou')->with('success', 'Order has been sent successfully.');
       } elseif ($request->payment == 'stripe') {
           // Process the Stripe payment method...
           // Implement your Stripe payment processing logic here
       }
   
       return redirect('/checkout')->with('error_message', 'Please select a valid payment method.');
   }
 public function thankyou(){
    return view('front.thanks');

 }
}