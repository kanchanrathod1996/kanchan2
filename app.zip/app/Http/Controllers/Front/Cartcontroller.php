<?php
  
namespace App\Http\Controllers\Front;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Session;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Subcategory;
use DataTables;
use File;
    

use Hash; 
use DB;
class Cartcontroller extends Controller
   {

    public function addProduct(Request $request)
    {
        // using ajax in front/productpage
       
       $product_id =$request->input('product_id');
       $product_qty =$request->input('product_qty');

    //    chech auth
                if(Auth::check())
                {
                    $prod_check = Product::where('id',$product_id)->first();    
                    
                                //  add to the cart
                                if($prod_check)
                                {
                                            if(Cart::where('prod_id',$product_id)->where('user_id',Auth::id())->exists())
                                            {
                                                return response()->json(['status'=> $prod_check->name." Already Added to cart"]);
                                            }
                                            else
                                            {

                                                $cartItem = new Cart();
                                                $cartItem ->prod_id = $product_id;
                                                $cartItem ->user_id = Auth::id();
                                                $cartItem ->prod_qty = $product_qty;
                                                $cartItem->save();
                                                
                                                return response()->json(['status'=> $prod_check->title."Added to cart"]);
                                            }

                                }   
                        
                }
                else{
                    return response()->json(['status'=> "Login to continue"]);
                }
    
    }
    public function viewcart(){



      $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
      $cartitems = Cart::where('user_id',Auth::id())->get();
      $product = Product::where('status',0)->get();
      
        return view('front.cart',compact('cartitems','categories','product'));   
    }   

    

    public function cartUpdate(Request $request)
    {

        $product_id = $request->input('prod_id');
        $product_qty = $request->input('prod_qty');
    
        if(Auth::check()) {
            if(Cart::where('prod_id', $product_id)->where('user_id', Auth::id())->exists()) {
                $cart = Cart::where('prod_id', $product_id)->where('user_id', Auth::id())->first();
                $cart->prod_qty = $product_qty;
                $cart->save(); // Use save() to update the existing record
    
                return response()->json(['status' => "Quantity updated successfully"]);
            }
        }
    }
    

    public function cartDelete(Request $request)
    {
    
        if(Auth::check())   
        {
            $prod_id = $request->input('prod_id');
          
                    if(Cart::where('prod_id',$prod_id)->where('user_id',Auth::id())->exists())
                    {
                 
                     
                        $cartitems = Cart::where('prod_id',$prod_id)->where('user_id', Auth::id())->first();
                      
                        $cartitems->delete();

                        
                        return response()->json(['status'=> "Product Deleted successfully.."]);
                 
                        
                    }
        }else{
            return response()->json(['status'=> "Login to continue"]);
        }

    }

    
      
   }
//    https://www.youtube.com/watch?v=7RW3c6yyaQQ&list=PL_99hMDlL4d3-n63bsNaaDRnTZdCOvU6q&index=23