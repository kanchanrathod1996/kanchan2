<?php
  
namespace App\Http\Controllers\Front;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Subcategory;
use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\User;
use App\Models\Product;
use App\Models\Wishlist;

use App\Models\CustomerAddress;



use Hash;
use Auth;


class Authcontroller extends Controller

{
   public function login(){
    $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();

    $data['categories'] =$categories;


    return view ('front.account.login',$data);
   }


   public function register(){
    $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();

    $data['categories'] = $categories;

    return view ('front.account.register',$data);
    
   }

   public function processRegister(Request $request){

        $validator = Validator::make($request->all(),[
             'name' =>'required|min:3',
             'email' =>'required|email|unique:users',
             'password' =>'required|min:5|confirmed'       
          ]);

        if($validator->passes()){
      $user = new User;
      $user->name = $request->name;
      $user->email = $request->email;
      $user->phone = $request->phone;
      $user->password = Hash::make($request->password);
      $user->save();

      session()->flash('success','you have been registerd successfully.');
      
      
      return response()->json([
            'status' =>true,
           
         ]);

            }else{

               return response()->json([
                  'status' =>false,
                  'errors' => $validator->errors()
               ]);
            }

   }



   public function authenticate(Request $request)
   {
     
      // print_r($request->all()); exit;
         

               $data = $request->all();

               $rules = array(
                  'email' => 'required|email',
                  'password' => 'required',
              );

               $validator = Validator::make($data, $rules);

               if($validator->passes()){

                        if(Auth::attempt(['email'=>$request->email,'password' =>$request->password], $request->get('remember'))){
                           
                           if(session()->has('url.intended'))
                           {
                              return redirect(session()->get('url.intended'));
                           }

                           return redirect()->route('front.profile');
                              }else{
                                 
                                 return redirect()->route('front.login')->withInput($request->only('email'))
                                 ->with('error','Either email/password is incorrect. ');
                                 
                              }
                  
            }else{
               return redirect()->route('front.login')->withErrors($validator)->withInput($request->only('email'));
            }
   }


      public function profile()
      {
         $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
           $user = User::where('id',Auth::user()->id)->first();

         $data['categories'] =$categories;
         $data['user'] =$user;

         return view('front.account.profile',$data);
      }


         public function updateProfile(Request $request){
             $userId = Auth::user()->id;

            $data = $request->all();

            $rules = array(
               'name' => 'required',
               'email' => 'required|email|unique:users,email,'.$userId.',id',
               'phone' => 'required',
           );

            $validator = Validator::make($data, $rules);

            if($validator->passes())
            {
               $user = User::find($userId);
               $user->name = $request->name;
               $user->email = $request->email;
               $user->phone = $request->phone;
               $user->save();
                         
               session()->flash('success','profile update successfully!..');
               return response()->json([
                  'status' =>true,
                  'message' => 'profile update successfully!..'
               ]);

            }else
            {

               return response()->json([
                  'status' =>false,
                  'errors' => $validator->errors()
               ]);
            }



         }

      public function logout()
      {
         Auth::logout();
         return redirect()->route('front.login')
         ->with('success','successfully logged out!');
         
      }
      public function order(){

         $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
         $user =Auth::user();
        $orders = Order::all();

        $data['categories'] = $categories ;
        $data['orders'] = $orders ;


   
         return view('front.account.order',$data);
   
       }
       public function orderDetail($id){

         $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
         $customeraddress = CustomerAddress::get();
         $orders = Order::get();
        $data['categories'] = $categories ;
        $data['orders'] = $orders ;

         
        $orderitem = OrderItem::where('orderId',$id)->get();//get orderId from orderitem table
         $data['orderitem'] =$orderitem;

         return view('front.account.orderDetail',$data);
       }
 //wishlist function  

         public function wishlist(){
            $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
           $wishlists = WishList::where('user_id',Auth::user()->id)->with('product')->get();

           return view('front.account.wishlist',compact('wishlists','categories'));
         }

      


         public function removeProductFromWishlist(Request $request)
         {
             $wishlist = WishList::where('user_id', Auth::user()->id)
                                 ->where('product_id', $request->id)
                                 ->first();
         
             if ($wishlist == null) {
                 session()->flash('error', 'Product already removed.');
             } else {
                 $wishlist->delete();
                 session()->flash('success', 'Product removed successfully.');
             }
         
             return response()->json([
                 'status' => true,
             ]);
         }
}
