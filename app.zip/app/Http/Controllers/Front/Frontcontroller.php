<?php
  
namespace App\Http\Controllers\Front;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use Session;
use App\Models\Cart;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\Page;
use App\Models\Wishlist;
use App\Models\Subcategory;
use app\Mail;
use Hash; 
use DB;
use PhpParser\Node\Expr\AssignOp\Div;

class Frontcontroller extends Controller
    {
    
     public function index()
          {
            $pages = Page::where('status',0)->get();
            $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
            $products = Product::where('is_featured','yes')->orderBy('id','DESC')->where('status',0)->take(8)->get();
            $data['featuredproducts'] = $products;

            $cart = Cart::where('user_id',Auth::id())->get();
            $data['cart'] = $cart;  

            $letestProducts = Product::orderBy('id','DESC')->where('status',0)->take(8)->get();
            $data['letestProducts'] = $letestProducts;

           return view ('front.home',$data,compact('categories','pages'));


          }
          

          public function page($slug)
          {
            $categories = Category::orderBy('name','ASC')->where('status',0)->get();
            $page = Page::where('slug',$slug)->first();
                if($page==null){
                        abort(404);
                        }

            return view ('front.page.page',compact('page','categories'));

          }
        //  contact page
    public function sentContactEmail(Request $request)
    {
     
            $validator = Validator::make($request->all(),[
              'name' =>'required',
              'email' =>'required|email|unique:users',
              'subject' =>'required|min:10'       
          ]);
          if($validator->passes()){
        //  send mail data
        $validatedData =[ 
          'name' => $request->name,
          'email' => $request->email,
          'subject' => $request->subject,
          'Message' => $request->Message,
        ];
        $admin = User::where('id',1)->first();
        Mail::to($admin->email)->send(new ContactFormMail($validatedData));

          
        
            session()->flash('success','you have been registerd successfully.');
            
            
            return response()->json([
                  'status' =>true,
                 
               ]);
      
                  }else{
      
                     return response()->json([
                        'status' =>false,
                        'errors' => $validator->errors()
                     ]);
                  }


    }

// wishlist function
          public function addToWishList(Request $request)
          {  

            
             if(Auth::check()==false){
              session(['url.intended'=>url()->previous()]);
              return response()->json([
                'status' =>false
              ]);
             }


            $product =Product::where('id',$request->id)->first();
            if($product==null)
            {

             return response()->json([
              'status' =>true,
              'message'=>'<div class="alert alert-danger">product not found.</div>'
              
            ]);
            }
            Wishlist::updateOrCreate(
                 ['user_id' =>Auth::user()->id,
                 'product_id' => $request->id,],

                 ['user_id' =>Auth::user()->id,
                 'product_id' => $request->id,],
            );

            //  $wishlist = new Wishlist;
            //  $wishlist->user_id = Auth::user()->id;
            //  $wishlist->product_id = $request->id;
            //  $wishlist->save();

             return response()->json([
              'status' =>true,
              'message'=>'<div class="alert alert-success"><strong>"'.$product->title.'" </strong>added wishlist successfully</div>',
              
            ]);

          }
          public function contact()
          {
             
  
              return view ('front.page.contact');
  
            }
  

          
    } 