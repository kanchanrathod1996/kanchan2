<?php
  
namespace App\Http\Controllers\Front;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\ProductRating;
use App\Models\Subcategory;
use App\Models\Category;
use App\Models\Cart;
use App\Models\Brand;
use App\Models\Product;


use DB;
use Illuminate\Support\Facades\Validator;

class shopcontroller extends Controller
    {
    
        public function index(Request $request,$categorySlug = null,$subcategorySlug = null)
        {
            $categorySelected = '';
            $subcategorySelected = '';
            $brandsArray = [];
           

            $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
            $brands = Brand::orderBy('name','ASC')->where('status',0)->get();
            $products = Product::where('status',0);
        //    apply filters here
          
        if(!empty($categorySlug ))
            {
          $category = Category::where('slug',$categorySlug)->first();
          $products =  $products->where('category_id',$category->id);
          $categorySelected  = $category->id;
            }


         if(!empty($subcategorySlug ))
            {
          $subcategory = Subcategory::where('slug',$subcategorySlug)->first();
          $products =  $products->where('subcategory_id',$subcategory->id);
          $subcategorySelected  = $subcategory->id;
            }

            if(!empty($request->get('brand')))

            {
                $brandsArray = explode(',' ,$request->get('brand'));
                $products =  $products->whereIn('brand_id',$brandsArray);
            }   
         
        

            $products =  $products->orderBy('id','DESC');
            $products =  $products->get();

            $data['categories'] =$categories;
            $data['brands'] =$brands;
        
            $data['products'] =$products;
            $data['categorySelected'] =$categorySelected;
            $data['subcategorySelected'] =$subcategorySelected;
            $data['brandsArray'] = $brandsArray;
  
  
              return view ('front.shop',$data);

                }

        public function product($slug){
              $product = Product::where('slug',$slug)
              ->withCount('product_ratings')
              ->withSum('product_ratings','rating')
              ->first();
              // dd($product);
              $categories = Category::orderBy('name','ASC')->with('subcategory')->where('status',0)->get();
              
              if($product==null) {
              abort(404);
              }
            // intialize variable  relatedproducts
              $relatedproducts = [];
              if($product->related_products!= ''){
                $productArray = explode(',',$product->related_products);
                $relatedproducts = Product::whereIn('id',$productArray)->get();
                
            }
               $data['product'] =$product;
              $data['categories'] =$categories;
              $data['relatedproducts'] =$relatedproducts; 



            // rating calculation ...

            // "product_ratings_count" => 0
            // "product_ratings_sum_rating" => null
            $avgRating = '0.00'; // Initialize as string
            $avgRatingPer = 0;    // Initialize as integer
            
            if ($product->product_ratings_count > 0 && $product->product_ratings_sum_rating !== null) {
                $avgRating = number_format(($product->product_ratings_sum_rating / $product->product_ratings_count), 2);
                $avgRatingPer = ($avgRating * 100) / 5; // Calculate percentage rating out of 5
            }
            
            $data['avgRating'] = $avgRating;
            $data['avgRatingPer'] = $avgRatingPer;
            
              return view('front.product',$data);
            }

         

//saveRating function
public function saveRating($id, Request $request)
{
    $validator = Validator::make($request->all(), [
        'username' => 'required',
        'email' => 'required|email',
        'comment' => 'required|min:10',
        'rating' => 'required',
    ]);


    if ($validator->fails()) {
        return response()->json([
            'status' => false,
            'errors' => $validator->errors(),
        ]);
    }
// here only one email give review only one time
    $count =ProductRating::where('email',$request->email)->count();
    if($count > 0){
      session()->flash('error', 'thanks, you have already Rating.');
      return response()->json([
                 'status'=>true,
                 'message' => 'thanks, you have already Rating',
      ]);
    }

    $productrating = new ProductRating;
    $productrating ->product_id =$id;
    $productrating ->username =$request->username;
    $productrating ->email =$request->email;
    $productrating ->comment =$request->comment;
    $productrating ->rating =$request->rating;
    $productrating ->status =0;
    $productrating->save();

    session()->flash('success', 'thank you for your Rating.');

    return response()->json([
        'status' => true,
        'message' => 'thank you for your Rating',
    ]);
}
  }