<?php
use App\Models\Product;


function getproductimage($prod_id)
{
    return Product::where('id',$prod_id)->first();
}

?>

